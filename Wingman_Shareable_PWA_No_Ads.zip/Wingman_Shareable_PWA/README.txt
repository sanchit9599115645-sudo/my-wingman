WINGMAN — SHAREABLE PWA (NO ADS INCLUDED)

What this is
- A mobile-friendly, installable website/PWA.
- No ads, trackers, analytics, account system, or chat-history database included.
- Screenshot and prompt are sent to Google Gemini when Generate is pressed.
- Each user should enter their own Gemini API key. Do not publish your personal key in the code or share it with friends.
- AI usage depends on the current free-tier availability and limits; unlimited free usage is not guaranteed.

PUBLISH FOR FREE USING GITHUB PAGES
1. Sign in at https://github.com/ and create a new PUBLIC repository, e.g. wingman-app.
2. Upload all files in this folder to the repository root: index.html, manifest.webmanifest, icon.svg, sw.js, README.txt.
3. In repository Settings -> Pages, select Deploy from a branch, choose main and / (root), then Save.
4. Wait for the Pages URL to appear. It will look like https://YOUR-USERNAME.github.io/wingman-app/ .
5. Open that HTTPS link on your phone and share it with your friend.

INSTALL ON PHONE
- Android Chrome: open the published link -> menu (three dots) -> Install app or Add to Home screen.
- iPhone Safari: open the link -> Share -> Add to Home Screen.
Browser wording can vary.

API KEY SETUP
1. Visit https://aistudio.google.com/apikey.
2. Create/check a key with available Gemini API free-tier access.
3. Each friend should use their own key. A key entered into this client-side demo is used in that browser session and is not saved by this page, but it is still present in browser memory while the page is open.
4. Do not add an API key to index.html or upload it to GitHub. Anyone who can access source code can read it.
5. Google AI Studio free-tier eligibility, model availability, quotas and terms may change. Check current official details at https://ai.google.dev/gemini-api/docs/pricing.

PRIVACY
- GitHub Pages hosts public static website files. Do not upload screenshots or keys to the repository.
- When a user presses Generate, their screenshot and prompt are sent to Google Gemini for processing.
- Avoid uploading sensitive or identifying details; crop or blur names and profile pictures.
- This is a simple personal-use prototype, not a security-audited production app.

FILES
- index.html: app UI and Gemini request
- manifest.webmanifest: installable app metadata
- icon.svg: app icon
- sw.js: caches static files for faster repeat loading
